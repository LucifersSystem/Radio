"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-ignore
var setup_1 = require("./System/core/setup");
(0, setup_1.setup)();
