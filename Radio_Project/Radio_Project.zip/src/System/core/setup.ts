// @ts-ignore
import {Load_Config} from "./config";

export function setup(){
    Load_Config();
}