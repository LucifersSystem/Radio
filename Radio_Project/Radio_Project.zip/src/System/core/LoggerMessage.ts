// @ts-ignore
import MessageGroup from "./MessageGroup";

type LoggerMessage = string | string[] | MessageGroup;

export default LoggerMessage;