"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setup = void 0;
// @ts-ignore
var config_1 = require("./config");
function setup() {
    (0, config_1.Load_Config)();
}
exports.setup = setup;
function Check_Config() {
}
