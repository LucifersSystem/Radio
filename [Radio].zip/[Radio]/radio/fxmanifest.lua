fx_version 'bodacious'
game 'gta5'
name 'radio'
description 'Lucifer Systems Radio (GUI SIDE)'
author 'Lucifer Systems'
version 'v2.0.0'
url 'https://api.luficersapi.live'

ui_page 'html/index.html'

files {
	'html/index.html',
	'html/fonts/digital_counter_7_italic.ttf',
	'html/fonts/ImperfectaRegular.ttf',
	'html/fonts/EFJFont.ttf',
	'html/layouts/**/*.*',
	'html/init.js',
	'html/fitText.js',
}

client_scripts{
	'client.lua'
}
